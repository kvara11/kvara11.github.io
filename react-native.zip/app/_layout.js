import { Drawer } from 'expo-router/drawer';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { Provider } from 'react-redux';
import { store } from '../store';

export default function Layout() {
  return (
    <Provider store={store}>
      <GestureHandlerRootView style={{ flex: 1 }}>
        <Drawer initialRouteName="index">
          <Drawer.Screen
            name="index"
            options={{
              drawerLabel: 'Home',
              title: 'Home',
            }}
          />
          <Drawer.Screen
            name="products"
            options={{
              drawerLabel: 'Products',
              title: 'Products',
            }}
          />
          <Drawer.Screen
            name="cart"
            options={{
              drawerLabel: 'Cart',
              title: 'Cart',
            }}
          />
        </Drawer>
      </GestureHandlerRootView>
    </Provider>
  );
}
